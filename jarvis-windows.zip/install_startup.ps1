$ErrorActionPreference = 'Stop'
$startup = [Environment]::GetFolderPath('Startup')
$target = Join-Path $startup 'JARVIS.lnk'
$exe = Join-Path $PSScriptRoot 'dist\JARVIS.exe'
if (-not (Test-Path $exe)) {
  Write-Error "dist\JARVIS.exe not found. Run build.ps1 first."
}
$ws = New-Object -ComObject WScript.Shell
$link = $ws.CreateShortcut($target)
$link.TargetPath = $exe
$link.WorkingDirectory = Split-Path $exe
$link.Description = 'Start JARVIS with Windows'
$link.Save()
Write-Host "JARVIS startup shortcut installed: $target" -ForegroundColor Green
