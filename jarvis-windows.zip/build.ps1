$ErrorActionPreference = 'Stop'
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name JARVIS jarvis.py
Copy-Item install_startup.ps1 dist\install_startup.ps1 -Force
Write-Host "Built dist\\JARVIS.exe" -ForegroundColor Green
Write-Host "Run dist\\install_startup.ps1 to start JARVIS with Windows" -ForegroundColor Cyan
