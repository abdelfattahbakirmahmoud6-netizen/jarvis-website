$ErrorActionPreference = 'Stop'
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name JARVIS jarvis.py
Write-Host "Built dist\\JARVIS.exe" -ForegroundColor Green
