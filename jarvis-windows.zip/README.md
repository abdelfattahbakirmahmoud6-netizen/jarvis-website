# JARVIS — Windows AI Assistant

نموذج أولي لمساعد Windows بواجهة كتابة وصوت. ينفذ أوامر آمنة مثل فتح البرامج والبحث ولقطات الشاشة والكتابة، ويطلب تأكيدًا قبل أوامر الإيقاف أو التشغيل أو حذف/تعديل الملفات.

## التشغيل على Windows

يفضّل Python 3.11 أو 3.12:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python jarvis.py
```

إذا فشل تثبيت `PyAudio`، شغّل النسخة النصية؛ كل الوظائف النصية ستظل تعمل. يمكن تثبيت `pipwin` ثم `pipwin install pyaudio` لتفعيل الميكروفون.

## إنشاء ملف EXE

```powershell
.\.venv\Scripts\Activate.ps1
pip install pyinstaller
pyinstaller --noconfirm --clean --onefile --windowed --name JARVIS jarvis.py
```

سيظهر الملف هنا:

```text
dist\JARVIS.exe
```

## تشغيل JARVIS تلقائيًا عند بدء Windows

بعد بناء ملف EXE، شغّل PowerShell من مجلد المشروع:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install_startup.ps1
```

سيتم إنشاء اختصار داخل مجلد Startup الخاص بالمستخدم، وسيبدأ JARVIS تلقائيًا بعد تسجيل الدخول إلى Windows وينطق جملة الترحيب.

### تغيير جملة الترحيب

بعد تشغيل JARVIS مرة واحدة، أنشئ الملف التالي:

```text
%APPDATA%\JARVIS\config.json
```

مثال:

```json
{
  "greeting": "أهلًا محمود، أنا JARVIS. جهازك جاهز، كيف أساعدك اليوم؟"
}
```

لا يحتاج الترحيب إلى اتصال بالإنترنت؛ يستخدم محرك النطق المحلي المثبت على Windows.

## أمثلة أوامر

- `افتح المفكرة` / `open notepad`
- `افتح Chrome`
- `ابحث عن أسعار الذهب`
- `اكتب Hello from JARVIS`
- `خذ لقطة شاشة`
- `شغّل calc.exe`

## حدود الأمان

هذا الإصدار لا يمنح نموذجًا لغويًا صلاحية غير محدودة على الجهاز. الأوامر الحساسة تطلب تأكيدًا، ولا يتم إرسال ملفاتك أو كلمات مرورك لأي خدمة. يمكن إضافة نموذج ذكاء اصطناعي لاحقًا لتحويل الكلام الطبيعي إلى أوامر مقيدة بقائمة صلاحيات.

## تطوير النسخة الكاملة

- wake word مثل “Hey JARVIS”
- تنفيذ تطبيقات مسموحة فقط عبر allowlist
- سجل أوامر قابل للمسح
- صلاحيات منفصلة للملفات والبرامج
- تكامل اختياري مع نموذج AI بمفتاح API محفوظ على جهاز المستخدم
