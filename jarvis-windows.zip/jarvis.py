import os
import re
import sys
import json
import queue
import threading
import subprocess
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from pathlib import Path

APP_NAME = "JARVIS"
CONFIG_PATH = Path(os.getenv("APPDATA", Path.home())) / "JARVIS" / "config.json"
DEFAULT_GREETING = "مرحبًا، أنا JARVIS. جهازك جاهز، كيف أساعدك اليوم؟"
DANGEROUS_WORDS = ("delete", "remove", "format", "shutdown", "restart", "kill", "taskkill", "registry", "install", "uninstall", "حذف", "مسح", "إيقاف", "إعادة تشغيل")

try:
    import pyttsx3
except Exception:
    pyttsx3 = None
try:
    import speech_recognition as sr
except Exception:
    sr = None
try:
    import pyautogui
except Exception:
    pyautogui = None

class Jarvis:
    def __init__(self, ui_log, ui_status):
        self.ui_log = ui_log
        self.ui_status = ui_status
        self.greeting = self.load_greeting()
        self.tts = None
        if pyttsx3:
            try:
                self.tts = pyttsx3.init()
                self.tts.setProperty("rate", 175)
            except Exception:
                self.tts = None

    def load_greeting(self):
        """Load a user-editable greeting without requiring a cloud service."""
        try:
            if CONFIG_PATH.exists():
                data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
                return data.get("greeting", DEFAULT_GREETING) or DEFAULT_GREETING
        except Exception:
            pass
        return DEFAULT_GREETING

    def welcome(self):
        self.say(self.greeting)

    def say(self, text):
        self.ui_log("JARVIS: " + text)
        if self.tts:
            threading.Thread(target=self._speak, args=(text,), daemon=True).start()

    def _speak(self, text):
        try:
            self.tts.say(text)
            self.tts.runAndWait()
        except Exception:
            pass

    def is_sensitive(self, command):
        c = command.lower()
        return any(word in c for word in DANGEROUS_WORDS)

    def execute(self, command, confirmed=False):
        command = command.strip()
        if not command:
            return
        self.ui_log("You: " + command)
        if self.is_sensitive(command) and not confirmed:
            return ("confirm", "هذا الأمر قد يغيّر أو يحذف شيئًا في Windows. هل تريد تنفيذه؟")
        c = command.lower()
        try:
            if any(x in c for x in ("hello", "hi", "مرحبا", "السلام")):
                self.say("مرحبًا. أنا JARVIS، جاهز لمساعدتك.")
            elif "time" in c or "الساعة" in c:
                self.say("الوقت الآن " + datetime.now().strftime("%H:%M"))
            elif c.startswith(("open ", "افتح ")):
                target = re.sub(r"^(open|افتح)\s+", "", command, flags=re.I).strip()
                self.open_target(target)
            elif c.startswith(("search ", "ابحث ")):
                query = re.sub(r"^(search|ابحث)\s+", "", command, flags=re.I).strip()
                webbrowser.open("https://www.google.com/search?q=" + query.replace(" ", "+"))
                self.say("فتحت نتائج البحث.")
            elif "screenshot" in c or "لقطة" in c:
                if pyautogui:
                    path = os.path.join(os.path.expanduser("~"), "Desktop", "jarvis-screenshot.png")
                    pyautogui.screenshot(path)
                    self.say("تم حفظ لقطة الشاشة على سطح المكتب.")
                else:
                    self.say("ثبّت pyautogui لتفعيل لقطات الشاشة.")
            elif c.startswith(("type ", "اكتب ")):
                text = re.sub(r"^(type|اكتب)\s+", "", command, flags=re.I)
                if pyautogui:
                    pyautogui.write(text, interval=0.02)
                    self.say("تمت الكتابة.")
                else:
                    self.say("ثبّت pyautogui لتفعيل التحكم في لوحة المفاتيح.")
            elif "shutdown" in c or "إيقاف" in c:
                subprocess.run(["shutdown", "/s", "/t", "30"], check=False)
                self.say("سيتم إيقاف Windows خلال 30 ثانية.")
            elif "restart" in c or "إعادة تشغيل" in c:
                subprocess.run(["shutdown", "/r", "/t", "30"], check=False)
                self.say("سيتم إعادة تشغيل Windows خلال 30 ثانية.")
            elif c.startswith(("run ", "نفذ ", "شغّل ")):
                raw = re.sub(r"^(run|نفذ|شغّل)\s+", "", command, flags=re.I)
                subprocess.Popen(raw, shell=True)
                self.say("تم تشغيل الأمر.")
            else:
                self.say("أستطيع فتح البرامج، البحث، كتابة النص، أخذ لقطة شاشة، وتشغيل أوامر Windows. جرّب: افتح Chrome")
        except Exception as exc:
            self.say("حدث خطأ: " + str(exc))
        return None

    def open_target(self, target):
        aliases = {
            "notepad": "notepad.exe", "المفكرة": "notepad.exe",
            "calculator": "calc.exe", "الحاسبة": "calc.exe",
            "explorer": "explorer.exe", "الملفات": "explorer.exe",
            "chrome": "chrome.exe", "edge": "msedge.exe",
            "settings": "ms-settings:", "الإعدادات": "ms-settings:"
        }
        target = aliases.get(target.lower(), target)
        if target.startswith("http://") or target.startswith("https://"):
            webbrowser.open(target)
        elif os.name == "nt":
            if target.endswith(":") or target.startswith("ms-"):
                os.startfile(target)
            else:
                subprocess.Popen(target, shell=True)
        else:
            self.say("هذا النموذج يعمل على Windows؛ تم تسجيل الأمر في وضع المعاينة.")
        self.say("تم فتح " + target)

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("JARVIS — Windows AI Assistant")
        self.geometry("760x560")
        self.minsize(620, 430)
        self.configure(bg="#07111f")
        self.pending = None
        self.log_box = tk.Text(self, bg="#0b1729", fg="#d8efff", insertbackground="white", relief="flat", font=("Segoe UI", 11), wrap="word")
        self.log_box.pack(fill="both", expand=True, padx=18, pady=(18, 8))
        bottom = tk.Frame(self, bg="#07111f")
        bottom.pack(fill="x", padx=18, pady=(0, 18))
        self.entry = ttk.Entry(bottom, font=("Segoe UI", 12))
        self.entry.pack(side="left", fill="x", expand=True, ipady=8)
        self.entry.bind("<Return>", lambda e: self.send())
        ttk.Button(bottom, text="إرسال", command=self.send).pack(side="left", padx=8)
        ttk.Button(bottom, text="🎙 استماع", command=self.listen).pack(side="left")
        self.status = tk.StringVar(value="جاهز")
        tk.Label(self, textvariable=self.status, bg="#07111f", fg="#68d5ff", anchor="w").pack(fill="x", padx=18, pady=(0, 10))
        self.jarvis = Jarvis(self.log, self.status.set)
        self.log("JARVIS: جاهز. اكتب أمرًا مثل: افتح المفكرة أو ابحث عن الطقس")
        self.after(900, self.jarvis.welcome)

    def log(self, text):
        self.after(0, lambda: (self.log_box.insert("end", text + "\n"), self.log_box.see("end")))

    def send(self):
        command = self.entry.get().strip()
        self.entry.delete(0, "end")
        if self.pending:
            if command.lower() in ("yes", "نعم", "موافق", "نعم نفذ"):
                pending = self.pending
                self.pending = None
                self.jarvis.execute(pending, confirmed=True)
            else:
                self.pending = None
                self.jarvis.say("تم إلغاء الأمر.")
            return
        result = self.jarvis.execute(command)
        if result and result[0] == "confirm":
            self.pending = command
            self.jarvis.say(result[1] + " اكتب نعم للتأكيد أو أي شيء للإلغاء.")

    def listen(self):
        if not sr:
            self.jarvis.say("لتفعيل الصوت ثبّت SpeechRecognition و PyAudio، ثم أعد تشغيل البرنامج.")
            return
        def worker():
            try:
                self.status.set("أستمع...")
                r = sr.Recognizer()
                with sr.Microphone() as source:
                    audio = r.listen(source, timeout=5, phrase_time_limit=8)
                text = r.recognize_google(audio, language="ar-EG")
                self.after(0, lambda: (self.entry.insert(0, text), self.send()))
            except Exception as exc:
                self.jarvis.say("لم أتعرف على الصوت. يمكنك الكتابة بدلًا من ذلك.")
            finally:
                self.status.set("جاهز")
        threading.Thread(target=worker, daemon=True).start()

if __name__ == "__main__":
    App().mainloop()
